# Scoring 1000 — standalone preset bank

This archive contains 1,000 native Surge XT FXP presets: ten categories of 100,
with 20 original synthesis families and five purposeful variants in each category.
It contains preset data and documentation; install Surge XT separately.

## Install in your user patch collection

1. Extract the ZIP into a temporary folder.
2. In Surge XT's patch-selector context menu, choose **Open User Patches Folder...**.
   This is the **Patches** folder beneath the configured user data folder. Using
   the menu respects custom and portable locations.
3. Copy the extracted **Scoring 1000** folder into that user Patches folder.
   Preserve the ten numbered category folders beneath it. Do not replace the
   entire Patches directory or overwrite your unrelated patches.
4. Refresh the patch browser or restart the synth, then find **Scoring 1000** in
   the user collection. If this bank already exists there, keep personal edits
   in a separate user folder before updating its original files.

Full factory-data installers built from the source repository already include the
bank in the factory collection. Plugin-only archives and minimal installations
can omit factory data. This standalone archive provides an additional user-bank
installation route; it does not embed presets into a plugin binary.

## Play and adapt

The eight consistent macros are Tone, Motion, Contour, Space, Color, Width,
Attack and Release. Space starts at 40%; set it to zero for a dry comparison.
Motion and Width at zero retain authored movement/spread rather than guaranteeing
stillness or mono. Velocity shapes dynamics; the wheel adds tone/motion, and
channel pressure adds vibrato. Times on analog envelopes are nominal settings.
Set track level with your intended phrase, especially with overlapping releases.

The catalog in **manifest.json** gives each preset's stable ID, native name,
musical role, suggested MIDI range, variant intent, macros and source SHA-256.
Catalog paths describe the source repository. **PACKAGE.json** maps those paths
to the actual archive paths, and **CONTENTS.sha256** verifies archive contents.
The companion .sha256 file outside the ZIP verifies the complete archive.

These are synthetic colors, including evocative keyboard, ensemble and vocal-like
textures; they do not contain recorded acoustic instruments. Technical packaging
checks do not establish listening approval or universal genre suitability.
Human audition and composer endorsement retain the statuses stated in the catalog.

Player guide and research:
https://github.com/tomasedisonn80/surgeXT-synth/blob/main/doc/scoring-1000/USER_GUIDE.md
https://github.com/tomasedisonn80/surgeXT-synth/blob/main/doc/scoring-1000/RESEARCH.md
Those online documents follow main; this archive's catalog and checksums identify
its exact preset data. Licensing and provenance are in LICENSE-NOTICE.txt.
