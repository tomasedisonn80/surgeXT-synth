#!/usr/bin/env python3
"""Focused measurements of shortlisted pairs, not a perceptual certification."""
from pathlib import Path
import hashlib
import json
import math
import subprocess
import sys
import numpy as np

ROOT = Path('/workspace/scratch/9118c5c72ad8/surgeXT-synth')
OUT = Path(__file__).resolve().parent
RENDERER = ROOT.parent / 'build-scoring/src/scoring-tools/surge-scoring-render'
sys.path.insert(0, str(ROOT / 'scripts/scoring'))
import qa_bank

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

pairs = [
    ('Felt Drum close/edge, shortest within-family ranking', 'SC10-001', 'SC10-003', 54),
    ('Felt Motor edge/pulse, related short bass articulations', 'SC07-093', 'SC07-095', 48),
    ('Leading matched cross-family pair', 'SC01-028', 'SC02-021', 63),
    ('Second matched cross-family pair', 'SC01-020', 'SC03-084', 68),
    ('Leading confounded cross-family pair, now common played note', 'SC10-005', 'SC10-034', 54),
]
catalog = json.loads((ROOT / 'doc/scoring-1000/manifest.json').read_text())
entries = {p['id']: p for p in catalog['presets']}
spec = {'sample_rate':48000, 'seconds':8, 'hold':3, 'velocity':96,
        'tempo':120, 'macros':'3=0', 'modwheel':0, 'pressure':0, 'expression':127}
rows=[]
inputs={}
for _, a, b, note in pairs:
    for ident in (a,b):
        p=entries[ident]
        patch=ROOT/p['path']
        inputs[ident]={'path':p['path'],'sha256':sha(patch),'name':p['name'],'note':note}
        rows.append('\t'.join(map(str,[patch,OUT/f'{ident}.f32',48000,8,3,note,96,120,'3=0',0,0,127])))
(OUT/'scenarios.tsv').write_text('\n'.join(rows)+'\n')
cmd=[str(RENDERER),'--data',str(ROOT/'resources/data'),'--batch',str(OUT/'scenarios.tsv'),
     '--report',str(OUT/'native.jsonl'),'--fresh-engine','1','--seed','1000']
completed=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
(OUT/'render.stdout').write_text(completed.stdout)
(OUT/'render.stderr').write_text(completed.stderr)
if completed.returncode:
    raise RuntimeError(f'native render failed: {completed.returncode}')
native=[json.loads(l) for l in (OUT/'native.jsonl').read_text().splitlines()]
if len(native)!=10 or any(not n.get('ok') for n in native):
    raise RuntimeError('native result missing or failed')

def fine_metrics(audio):
    # Analytical normalization only: original renderer samples are retained raw.
    early=audio[:round(.6*48000)].astype(float)
    env=np.sqrt(np.mean(early.reshape(-1,240,2)**2,axis=(1,2)))
    power=np.zeros(2049)
    window=np.hanning(4096)[:,None]
    block=audio[:48000].astype(float)
    for start in range(0,len(block)-4096+1,2048):
        power+=(np.abs(np.fft.rfft(block[start:start+4096]*window,axis=0))**2).sum(axis=1)
    frequency=np.fft.rfftfreq(4096,1/48000)
    total=float(power.sum())
    band=[float(power[(frequency>=lo)&(frequency<hi)].sum()/max(total,1e-30))
          for lo,hi in zip(qa_bank.CONFIG['spectral_band_edges_hz'][:-1],qa_bank.CONFIG['spectral_band_edges_hz'][1:])]
    energy=(audio.astype(float)**2).sum(axis=1)
    cumulative=np.cumsum(energy)/max(float(energy.sum()),1e-30)
    return {'rms_envelope_5ms_first_600ms':env.tolist(),
            'spectral_energy_first_second':band,
            'centroid_first_second_hz':float(np.dot(frequency,power)/max(total,1e-30)),
            'time_50_percent_energy_s':float(np.searchsorted(cumulative,.5)/48000),
            'time_90_percent_energy_s':float(np.searchsorted(cumulative,.9)/48000)}

audio={}; metrics={}; fine={}
for ident,p in inputs.items():
    audio[ident],metrics[ident]=qa_bank.measure(OUT/f'{ident}.f32',spec)
    fine[ident]=fine_metrics(audio[ident])
    if sha(ROOT/p['path'])!=p['sha256']:
        raise RuntimeError(f'{ident}: input changed during render')
comparisons=[]
for label,a,b,note in pairs:
    x=audio[a][:144000].astype(float); y=audio[b][:144000].astype(float)
    alpha=float(np.sum(x*y)/max(float(np.sum(y*y)),1e-30))
    residual=float(np.sqrt(np.sum((x-alpha*y)**2)/max(float(np.sum(x*x)),1e-30)))
    ea=np.array(fine[a]['rms_envelope_5ms_first_600ms']); eb=np.array(fine[b]['rms_envelope_5ms_first_600ms'])
    escale=float(np.dot(ea,eb)/max(float(np.dot(eb,eb)),1e-30))
    erel=float(np.linalg.norm(ea-escale*eb)/max(float(np.linalg.norm(ea)),1e-30))
    comparisons.append({'reason':label,'id_a':a,'id_b':b,'name_a':inputs[a]['name'],'name_b':inputs[b]['name'],
        'played_note':note,'dry_coarse_feature_distance':qa_bank.compare_features(metrics[a],metrics[b]),
        'dry_raw_relative_waveform_rms_delta':qa_bank.compare_waveforms(x,y),
        'dry_waveform_least_squares_gain_b_to_a':alpha,
        'dry_waveform_gain_removed_relative_residual':residual,
        'early_600ms_envelope_gain_removed_relative_residual':erel,
        'early_1s_spectral_fraction_l2':float(np.linalg.norm(np.array(fine[a]['spectral_energy_first_second'])-np.array(fine[b]['spectral_energy_first_second']))),
        'dry_active_rms_ratio_db':20*math.log10(metrics[b]['active_rms']/metrics[a]['active_rms']),
        'pcm_equal':metrics[a]['pcm_sha256']==metrics[b]['pcm_sha256']})
result={'schema':1,'scope':'Ten fresh native dry renders for five targeted pairs, with common playing fixtures.',
    'script_sha256':sha(__file__),'renderer_sha256':sha(RENDERER),'qa_helper_sha256':sha(qa_bank.__file__),
    'native_report_sha256':sha(OUT/'native.jsonl'),'batch_sha256':sha(OUT/'scenarios.tsv'),
    'command':cmd,'inputs':inputs,'fixture':spec,'seed':1000,'native':native,
    'metrics':metrics,'fine_metrics':fine,'pairs':comparisons,
    'limits':['These measurements do not certify a perceptually useful difference or human musical audition.',
              'Waveform residual is sensitive to phase and random detail; fine envelope and spectral fractions discard other detail.',
              'Space=0 removes mapped effects mix; saved voice gain and other saved macros remain unchanged.',
              'Gain fitting is analytical only; all native render PCM remains unnormalized.',
              'Measurements cover one note/velocity/tempo and no complete musical phrase.'],
    'musical_audition':'pending','composer_endorsement':'not_claimed'}
(OUT/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(comparisons,indent=2))
